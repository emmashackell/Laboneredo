//input

let diameter=.5;
let height=2.5;

//processing
let radius = diameter / 2;
let volume = Math.PI * radius * radius * height;
//output
console.log(`The volume of a cylinder with diameter ${diameter} and height ${height} is $ {volume}`);