//input
let kilometers = 56;

//processing
let miles = kilometers * 0.621371;
//output

console.log(`${kilometers} km is ${miles} miles`)